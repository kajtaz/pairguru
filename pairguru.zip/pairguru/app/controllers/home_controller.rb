class HomeController < ApplicationController
  def welcome; end
end
