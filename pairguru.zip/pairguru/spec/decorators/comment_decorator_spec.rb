require 'rails_helper'

RSpec.describe CommentDecorator do
end
