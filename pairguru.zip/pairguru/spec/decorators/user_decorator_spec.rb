require 'rails_helper'

RSpec.describe UserDecorator do
end
