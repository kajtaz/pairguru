FactoryBot.define do
  factory :comment do
    content "MyText"
    user nil
    movie nil
  end
end
