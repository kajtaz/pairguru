


def balance_parenthesis(str)
  stack = []

  str.each_char do |ch|
  case ch
  when "("
    stack << ch
  when ")"
    return false if stack.empty?
    stack.pop
  end
end

true
end

balanced = "(abc(123))"
unbalanced = ")(abc(123))"

x = p balance_parenthesis?(balanced)
